package com.cg.CapStore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Coupon")
public class Coupon 
{
	@Id
	@Column(name="coupon_Code")
	private String couponCode;
	
	@Column(name="coupon_Amount")
	private double couponAmount;

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public double getCouponAmount() {
		return couponAmount;
	}

	public void setCouponAmount(double couponAmount) {
		this.couponAmount = couponAmount;
	}

	public Coupon(String couponCode, double couponAmount) {
		super();
		this.couponCode = couponCode;
		this.couponAmount = couponAmount;
	}

	public Coupon() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}

package com.cg.CapStore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.CapStore.dto.Coupon;


@Repository("capSDao")
public class CapstoreDaoImpl implements ICapstoreDao 
{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public void insertdata(Coupon Coupon) 
	{
		em.persist(Coupon);
		em.flush();
		
	}

	@Override
	public List<Coupon> getAllCoupons() 
	{
		TypedQuery<Coupon> query= (TypedQuery<Coupon>) em.createQuery("From Coupon");
		return query.getResultList();
	}
}

package com.cg.CapStore.dao;

import java.util.List;

import com.cg.CapStore.dto.Coupon;

public interface ICapstoreDao {
	//public List <Coupon> insertdata(String c, double a);
	public void insertdata(Coupon coupon);
	public List<Coupon> getAllCoupons();
}

package com.cg.CapStore.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.CapStore.dao.ICapstoreDao;
import com.cg.CapStore.dto.Coupon;

@Service("capSService")
@Transactional
public class CapstoreServiceImpl implements ICapstoreService 
{
	@Autowired
	ICapstoreDao capSDao;

	@Override
	public void insertdata(Coupon coupon) {
		
		 capSDao.insertdata(coupon);
	}

	@Override
	public List<Coupon> getAllCoupons() {
		
		return capSDao.getAllCoupons();
	}
}

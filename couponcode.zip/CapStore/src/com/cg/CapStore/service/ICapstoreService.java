package com.cg.CapStore.service;

import java.util.List;

import com.cg.CapStore.dto.Coupon;

public interface ICapstoreService {

	public void insertdata(Coupon coupon);
	public List<Coupon> getAllCoupons();
}
